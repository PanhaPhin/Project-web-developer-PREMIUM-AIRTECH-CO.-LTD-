export const name = 'warmupData' as const

export const WarmupDataEnricherSymbol = Symbol('WarmupDataEnricher')
export const WarmupDataProviderSymbol = Symbol('WarmupDataProvider')
export const WarmupDataAggregatorSymbol = Symbol('WarmupDataAggregator')
export const WarmupDataPromiseSymbol = Symbol('WarmupDataPromise')
