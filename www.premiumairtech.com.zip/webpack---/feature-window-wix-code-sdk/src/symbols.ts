export const name = 'windowWixCodeSdk' as const
export const namespace = 'window' as const
export const WindowWixCodeSdkWarmupDataEnricherSymbol = Symbol('WindowWixCodeSdkWarmupDataEnricher')
