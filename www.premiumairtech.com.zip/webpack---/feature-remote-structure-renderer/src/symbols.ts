export const name = 'remoteStructureRenderer' as const
