export const name = 'protectedPages' as const
