export const DynamicFeatureLoader = Symbol('DynamicFeatureLoader')
