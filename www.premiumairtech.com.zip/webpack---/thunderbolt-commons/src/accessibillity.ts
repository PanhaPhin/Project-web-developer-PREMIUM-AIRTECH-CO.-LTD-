export const tabClasses = ['focus-ring-active', 'keyboard-tabbing-on']
