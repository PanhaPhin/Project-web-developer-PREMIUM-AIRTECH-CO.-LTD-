export const whitelistedEndpoints = [
	new URL('https://sled.wix.dev'),
	new URL('https://bo.wix.com/suricate/tunnel/'),
	new URL('https://localhost'),
	new URL('http://localhost'),
]
