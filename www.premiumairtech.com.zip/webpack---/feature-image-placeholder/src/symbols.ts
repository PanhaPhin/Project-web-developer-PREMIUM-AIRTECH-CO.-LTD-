export const name = 'imagePlaceholder' as const

export const ImagePlaceholderSymbol = Symbol('ImagePlaceholder')
