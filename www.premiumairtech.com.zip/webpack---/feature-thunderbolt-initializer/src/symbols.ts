export const name = 'thunderboltInitializer' as const

export const Thunderbolt = Symbol('Thunderbolt')
