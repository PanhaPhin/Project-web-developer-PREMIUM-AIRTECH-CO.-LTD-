export const name = 'editorWixCodeSdk' as const
export const namespace = 'editor' as const
