export const Animations = Symbol('Animations')
export const EditorAnimationsSym = Symbol('EditorAnimations')
export const CreateAnimatorManagerSymbol = Symbol('CreateAnimatorManager')

export const name = 'animations' as const
